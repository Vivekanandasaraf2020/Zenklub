package Steps;

import java.util.concurrent.TimeUnit;



import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDSL {

	WebDriver driver;
	JavascriptExecutor js = (JavascriptExecutor) driver;  


	@Given("^the User is on Zenklub$")
	public void the_User_is_on_Zenklub() {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\eclipse-workspace\\DSL\\Lib\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.navigate().to("https://zenklub.com.br/auth/login");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}

	@When("^he is entered the UserID and Password$")
	public void he_is_entered_the_UserID_and_Password() {

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		WebElement userName = driver.findElement(By.id("login-form-email"));
		userName.clear();
		userName.click();
		userName.sendKeys("qachallenge@zenklub.com");
		WebElement passWord = driver.findElement(By.id("login-form-password"));
		passWord.clear();
		passWord.click();
		passWord.sendKeys("qachallenge");
		WebElement submit = driver.findElement(By.xpath("//button[@class='btn btn-lg btn-primary w-100']"));
		submit.click();

		// Write code here that turns the phrase above into concrete actions

	}
	
	@When("^he is on the Homepage$")
	public void he_is_on_the_Homepage() {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		WebElement HomePage = driver.findElement(By.xpath("//a[@class='logo']"));
		System.out.println(HomePage.isDisplayed());
		
	}

	@When("^he click on the search professional to find a professional$")
	public void he_click_on_the_search_professional_to_find_a_professional() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		WebElement searchProfessional = driver.findElement(By.xpath("//a[@href='busca']"));  
		//WebElement searchProfessional = driver.findElement(By.xpath("//a[contains(text(),'NOSSOS ESPECIALISTAS')]"));
		searchProfessional.click();
		WebElement searchProfessionalvalidator = driver.findElement(By.xpath("//input[@placeholder='Procure por motivo, nome ou especialidade...']"));
		System.out.println(searchProfessionalvalidator.isDisplayed());
		
		WebElement userNameField = driver.findElement(By.xpath("(//*[contains(@class,'user_info')]//h2)[1]"));
		userNameField.getText();
		System.out.println("sssssssssssssss");
		//js.executeScript("window.scrollBy(0,1000)");
	}
	@When("^he is clicking on the first professional$")
	public void he_is_clicking_on_the_first_professional() {
		
		WebElement searchFirstProfessional = driver.findElement(By.xpath("(//*[contains(text(),' Gostei 💜 quero saber mais! ')])[1]"));
		searchFirstProfessional.click();
		searchFirstProfessional.sendKeys(Keys.PAGE_DOWN);
		
		WebElement userDropdown = driver.findElement(By.xpath("//div[@id='user_menu']"));
		userDropdown.click();
		
		
		//driver.close();
		//searchFirstProfessional.click();
		

		
		//String professionalName = driver.findElement(By.xpath("//h2[contains(text(),'Celio Tinti')]")).getText();
		//System.out.println(professionalName);
		//Assert.assertTrue("Text not found!", professionalName.contains("celio-tinti"));
		//String actualGooglePageTitlte = "Ravena Pereira Diniz - Psicólogo Online | Zenklub";
		//String PageTitlte=driver.getTitle();
		//System.out.println("Google page title" + actualGooglePageTitlte);   
		//Verify expected page title and actual page title is same  
		//Assert.assertEquals(PageTitlte, "Ravena Pereira Diniz - Psicólogo Online | Zenklub");
		//Assert.assertTrue(actualGooglePageTitlte.equalsIgnoreCase(PageTitlte),"Ravena Pereira Diniz - Psicólogo Online | Zenklub");     
		
	}
	
	@Then("^logout and close browser$")
	public void logout_and_close_browser(WebDriver driver) {
		
		
		
		
		    driver.close();
		}
		//WebElement slot = driver.findElement(By.xpath("//div[@class='timezone-title']"));
		//slot.isDisplayed();
		
		
		
	
	

}
